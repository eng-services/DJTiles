/*
    Theme Name: Savoye
	Theme URI: http://shtheme.org/demosd/savoye
	Author: Shtheme
	Author URI: https://themeforest.net/user/shtheme
    Release Date: 27 November 2021
    Requirements: WordPress 4.0 or higher, PHP 5
    Compatibility: WordPress 4.9.1
    Tags: web app
    Last Update Date: 27 November 2021
*/

/**** Readme ****/

"Please backup your theme pack files at first before you update the theme into the latest version"


2021.11.27 - version 1.0.0
- First release.