<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsTestimonials extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-testimonials';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Testimonials', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Testimonials widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Testimonials widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'testimonials' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'bdevs-elementor'),
	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
	        'center'        => esc_html__('Center', 'bdevs-elementor') ,
	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
	    ];

	    return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_heading',
			[
				'label' => esc_html__( 'Testimonials', 'bdevs-elementor' ),
			]	
		);

		$this->add_control(
			'chose_style',
			[
				'label'     => esc_html__( 'Select Style', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'style_1'  => esc_html__( 'Normal', 'bdevs-elementor' ),
					'style_2' => esc_html__( 'Carousel', 'bdevs-elementor' ),
				],
				'default'   => 'style_1',
			]
		);

		$this->add_control(
			'background_bg',
			[
				'label'   => esc_html__( 'Background Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add image from here', 'bdevs-elementor' ),
				'condition' => [
                    'chose_style' => ['style_2']
                ],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_item',
			[
				'label' => esc_html__( 'Testimonials Items', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'tabs',
			[
				'label' => esc_html__( 'Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => [	
					[
						'name'    => 'tab_image',
						'label'   => esc_html__( 'Image', 'bdevs-elementor' ),
						'type'    => Controls_Manager::MEDIA,
						'dynamic' => [ 'active' => true ],
					],
					[
						'name'        => 'name',
						'label'       => esc_html__( 'Name', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Name' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'info',
						'label'       => esc_html__( 'Information', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Information' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'quote',
						'label'       => esc_html__( 'Quote', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Quote' , 'bdevs-elementor' ),
						'label_block' => true,
					],

				],
			]
		);

		$this->end_controls_section();


		/** 
		*	Layout section 
		**/
		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);	

		$this->end_controls_section();

	}

	public function render() {
		$settings  = $this->get_settings_for_display();
		extract($settings);?>
		<?php if( $chose_style == 'style_1' ): ?>
		<div class="testimonials section-padding" id="testimonials">
	        <div class="container">
	            <div class="row">
	            	<?php 
	                    foreach ( $settings['tabs'] as $item ) : 
					?>
	                <div class="col-md-4">
	                    <div class="item-box mb-30"> <span class="quote">
	                            <img src="<?php echo get_template_directory_uri();?>/img/quot.png" alt="">
	                        </span>
	                        <p><?php print wp_kses_post($item['quote']); ?></p>
	                        <div class="info">
	                            <div class="author-img"> <img src="<?php echo wp_kses_post($item['tab_image']['url']); ?>" alt=""> </div>
	                            <div class="cont">
	                                <h6><?php print wp_kses_post($item['name']); ?></h6> <span><?php print wp_kses_post($item['info']); ?></span>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            	<?php endforeach; ?>
	            </div>
	        </div>
	    </div>
	    <?php elseif( $chose_style == 'style_2' ): ?>
		<div class="testimonials section-padding bg-img bg-fixed" data-overlay-dark="5" data-background="<?php echo wp_kses_post($settings['background_bg']['url']); ?>">
	        <div class="container">
	            <div class="row">
	                <div class="owl-carousel owl-theme col-md-12">
	                	<?php 
		                    foreach ( $settings['tabs'] as $item ) : 
						?>
	                    <div class="item-box"><span class="quote"><img src="<?php echo get_template_directory_uri();?>/img/quot.png" alt=""></span>
	                        <p><?php print wp_kses_post($item['quote']); ?></p>
	                        <div class="info">
	                            <div class="author-img"> <img src="<?php echo wp_kses_post($item['tab_image']['url']); ?>" alt=""> </div>
	                            <div class="cont">
	                                <h6><?php print wp_kses_post($item['name']); ?></h6> <span><?php print wp_kses_post($item['info']); ?></span>
	                            </div>
	                        </div>
	                    </div>
	                	<?php endforeach; ?>
	                </div>
	            </div>
	        </div>
	    </div>
		<?php endif; ?>
	<?php
	}

}