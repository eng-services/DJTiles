<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsProject02 extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-portfolio-two';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Project Version 2', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Project widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Project widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'portfolio' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'bdevs-elementor'),
	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
	        'center'        => esc_html__('Center', 'bdevs-elementor') ,
	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
	    ];

	    return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_heading',
			[
				'label' => esc_html__( 'Project', 'bdevs-elementor' ),
			]	
		);

		$this->add_control(
			'post_number',
			[
				'label'     => esc_html__( 'Project Count', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your count', 'bdevs-elementor' ),
				'default'   => '6',
				'label_block' => true,
			]
		);

		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);

		$this->end_controls_section();

		/** 
		*	Layout section 
		**/
		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);		

		$this->end_controls_section();

	}

	public function render() {
		$settings  = $this->get_settings_for_display(); 
		extract($settings);	
		$post_number = $settings['post_number'];
	    $order = $settings['post_order'];
	    $wp_query = new \WP_Query(array('posts_per_page' => $post_number,'post_type' => 'project',  'orderby' => 'ID', 'order' => $order));
	   
	    //other style
	    $args = array('posts_per_page' => $post_number,'post_type' => 'project',  'orderby' => 'ID', 'order' => $order);	
	   	?>
	   	<div class="project section-padding">
	        <div class="container">
	            <div class="row">
	            	<?php $i=0;
		                $args = new \WP_Query(array(   
		                            'post_type' => 'project', 
		                        ));  
		                while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
		                $i++;
		                $cates = get_the_terms(get_the_ID(),'type1');

		                    $cate_name ='';

		                    $cate_slug = '';

		                    foreach((array)$cates as $cate){

		                        $cate_name .= $cate->name.'  ' ;

		                        $cate_slug .= $cate->slug .' '; 

		                } 
		            ?>
		            <?php $address = get_post_meta(get_the_ID(),'_cmb_address', true); ?>
		            <?php if($i ==1){ ?>
	                <div class="col-12 col-md-6 project-masonry-wrapper-padding">
	                    <div class="portfolio-item-wrapp">
	                        <div class="portfolio-item">
	                            <div class="project-masonry-wrapper">
	                                <a href="<?php the_permalink(); ?>" class="project-masonry-item-img-link"> <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="" />
	                                    <div class="project-masonry-item-img"></div>
	                                    <div class="project-masonry-item-content">
	                                        <h4 class="project-masonry-item-title"><?php the_title(); ?></h4>
	                                        <div class="project-masonry-item-category"><?php echo esc_attr($address); ?></div>
	                                    </div>
	                                </a>
	                            </div>
	                        </div>
	                    </div>
	                	<?php }elseif($i == 2){ ?>
	                    <div class="portfolio-item-wrapp">
	                        <div class="portfolio-item">
	                            <div class="project-masonry-wrapper">
	                                <a href="<?php the_permalink(); ?>" class="project-masonry-item-img-link"> <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="" />
	                                    <div class="project-masonry-item-img"></div>
	                                    <div class="project-masonry-item-content">
	                                        <h4 class="project-masonry-item-title"><?php the_title(); ?></h4>
	                                        <div class="project-masonry-item-category"><?php echo esc_attr($address); ?></div>
	                                    </div>
	                                </a>
	                            </div>
	                        </div>
	                    </div>
	                	<?php }elseif($i == 3){ ?>
	                    <div class="portfolio-item-wrapp">
	                        <div class="portfolio-item">
	                            <div class="project-masonry-wrapper">
	                                <a href="<?php the_permalink(); ?>" class="project-masonry-item-img-link"> <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="" />
	                                    <div class="project-masonry-item-img"></div>
	                                    <div class="project-masonry-item-content">
	                                        <h4 class="project-masonry-item-title"><?php the_title(); ?></h4>
	                                        <div class="project-masonry-item-category"><?php echo esc_attr($address); ?></div>
	                                    </div>
	                                </a>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            	<?php }elseif($i == 4){ ?>
	                <div class="col-12 col-md-6 project-masonry-wrapper-padding">
	                    <div class="portfolio-item-wrapp">
	                        <div class="portfolio-item">
	                            <div class="project-masonry-wrapper">
	                                <a href="<?php the_permalink(); ?>" class="project-masonry-item-img-link"> <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="" />
	                                    <div class="project-masonry-item-img"></div>
	                                    <div class="project-masonry-item-content">
	                                        <h4 class="project-masonry-item-title"><?php the_title(); ?></h4>
	                                        <div class="project-masonry-item-category"><?php echo esc_attr($address); ?></div>
	                                    </div>
	                                </a>
	                            </div>
	                        </div>
	                    </div>
	                	<?php }elseif($i == 5){ ?>
	                    <div class="portfolio-item-wrapp">
	                        <div class="portfolio-item">
	                            <div class="project-masonry-wrapper">
	                                <a href="<?php the_permalink(); ?>" class="project-masonry-item-img-link"> <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="" />
	                                    <div class="project-masonry-item-img"></div>
	                                    <div class="project-masonry-item-content">
	                                        <h4 class="project-masonry-item-title"><?php the_title(); ?></h4>
	                                        <div class="project-masonry-item-category"><?php echo esc_attr($address); ?></div>
	                                    </div>
	                                </a>
	                            </div>
	                        </div>
	                    </div>
	                	<?php }elseif($i == 6){ ?>
	                    <div class="portfolio-item-wrapp">
	                        <div class="portfolio-item">
	                            <div class="project-masonry-wrapper">
	                                <a href="<?php the_permalink(); ?>" class="project-masonry-item-img-link"> <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="" />
	                                    <div class="project-masonry-item-img"></div>
	                                    <div class="project-masonry-item-content">
	                                        <h4 class="project-masonry-item-title"><?php the_title(); ?></h4>
	                                        <div class="project-masonry-item-category"><?php echo esc_attr($address); ?></div>
	                                    </div>
	                                </a>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            	<?php }else{ ?>
	            	<?php } ?>
	                <?php   
				        endwhile; 
				        wp_reset_postdata();
				    ?>
	            </div>
	        </div>
	    </div>
	<?php
	}

}