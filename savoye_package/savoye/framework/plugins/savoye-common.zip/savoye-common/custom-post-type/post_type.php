<?php


// register post type1 Project

add_action( 'init', 'register_savoye_Project' );

function register_savoye_Project() {

    

    $labels = array( 

        'name' => __( 'Project', 'savoye' ),

        'singular_name' => __( 'Project', 'savoye' ),

        'add_new' => __( 'Add New Project', 'savoye' ),

        'add_new_item' => __( 'Add New Project', 'savoye' ),

        'edit_item' => __( 'Edit Project', 'savoye' ),

        'new_item' => __( 'New Project', 'savoye' ),

        'view_item' => __( 'View Project', 'savoye' ),

        'search_items' => __( 'Search Project', 'savoye' ),

        'not_found' => __( 'No Project found', 'savoye' ),

        'not_found_in_trash' => __( 'No Project found in Trash', 'savoye' ),

        'parent_item_colon' => __( 'Parent Project:', 'savoye' ),

        'menu_name' => __( 'Project', 'savoye' ),

    );



    $args = array( 

        'labels' => $labels,

        'hierarchical' => true,

        'description' => 'List Project',

        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),

        'taxonomies' => array( 'Project', 'type1','category1' ),

        'public' => true,

        'show_ui' => true,

        'show_in_menu' => true,

        'menu_position' => 5,

        'menu_icon' => 'dashicons-portfolio', 

        'show_in_nav_menus' => true,

        'publicly_queryable' => true,

        'exclude_from_search' => false,

        'has_archive' => true,

        'query_var' => true,

        'can_export' => true,

        'rewrite' => true,

        'capability_type' => 'post'

    );



    register_post_type( 'Project', $args );

}

add_action( 'init', 'create_type1_hierarchical_taxonomy', 0 );

add_action( 'init', 'create_Category1_hierarchical_taxonomy', 0 );


//create a custom taxonomy name it Skillss for your posts



function create_type1_hierarchical_taxonomy() {



// Add new taxonomy, make it hierarchical like Skills

//first do the translations part for GUI



  $labels = array(

    'name' => __( 'Type', 'savoye' ),

    'singular_name' => __( 'Type', 'savoye' ),

    'search_items' =>  __( 'Search Type','savoye' ),

    'all_items' => __( 'All Type','savoye' ),

    'parent_item' => __( 'Parent Type','savoye' ),

    'parent_item_colon' => __( 'Parent Type:','savoye' ),

    'edit_item' => __( 'Edit Type','savoye' ), 

    'update_item' => __( 'Update Type','savoye' ),

    'add_new_item' => __( 'Add New Type','savoye' ),

    'new_item_name' => __( 'New Type Name','savoye' ),

    'menu_name' => __( 'Type','savoye' ),

  );     



// Now register the taxonomy



  register_taxonomy('type1',array('Project'), array(

    'hierarchical' => true,

    'labels' => $labels,

    'show_ui' => true,

    'show_admin_column' => true,

    'query_var' => true,

    'rewrite' => array( 'slug' => 'type1' ),

  ));



}

function create_Category1_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Category', 'savoye' ),
    'singular_name' => __( 'Category', 'savoye' ),
    'search_items' =>  __( 'Search Category','savoye' ),
    'all_items' => __( 'All Category','savoye' ),
    'parent_item' => __( 'Parent Category','savoye' ),
    'parent_item_colon' => __( 'Parent Category:','savoye' ),
    'edit_item' => __( 'Edit Category','savoye' ), 
    'update_item' => __( 'Update Category','savoye' ),
    'add_new_item' => __( 'Add New Category','savoye' ),
    'new_item_name' => __( 'New Category Name','savoye' ),
    'menu_name' => __( 'Category','savoye' ),
  );     

// Now register the taxonomy

  register_taxonomy('category1',array('Project'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'category1' ),
  ));

}

// register post type2 Service

add_action( 'init', 'register_savoye_Service' );

function register_savoye_Service() {

    

    $labels = array( 

        'name' => __( 'Service', 'savoye' ),

        'singular_name' => __( 'Service', 'savoye' ),

        'add_new' => __( 'Add New Service', 'savoye' ),

        'add_new_item' => __( 'Add New Service', 'savoye' ),

        'edit_item' => __( 'Edit Service', 'savoye' ),

        'new_item' => __( 'New Service', 'savoye' ),

        'view_item' => __( 'View Service', 'savoye' ),

        'search_items' => __( 'Search Service', 'savoye' ),

        'not_found' => __( 'No Service found', 'savoye' ),

        'not_found_in_trash' => __( 'No Service found in Trash', 'savoye' ),

        'parent_item_colon' => __( 'Parent Service:', 'savoye' ),

        'menu_name' => __( 'Service', 'savoye' ),

    );



    $args = array( 

        'labels' => $labels,

        'hierarchical' => true,

        'description' => 'List Service',

        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),

        'taxonomies' => array( 'Service', 'type2' ),

        'public' => true,

        'show_ui' => true,

        'show_in_menu' => true,

        'menu_position' => 5,

        'menu_icon' => 'dashicons-portfolio', 

        'show_in_nav_menus' => true,

        'publicly_queryable' => true,

        'exclude_from_search' => false,

        'has_archive' => true,

        'query_var' => true,

        'can_export' => true,

        'rewrite' => true,

        'capability_type' => 'post'

    );



    register_post_type( 'Service', $args );

}

add_action( 'init', 'create_type2_hierarchical_taxonomy', 0 );



//create a custom taxonomy name it Skillss for your posts



function create_type2_hierarchical_taxonomy() {



// Add new taxonomy, make it hierarchical like Skills

//first do the translations part for GUI



  $labels = array(

    'name' => __( 'Type', 'savoye' ),

    'singular_name' => __( 'Type', 'savoye' ),

    'search_items' =>  __( 'Search Type','savoye' ),

    'all_items' => __( 'All Type','savoye' ),

    'parent_item' => __( 'Parent Type','savoye' ),

    'parent_item_colon' => __( 'Parent Type:','savoye' ),

    'edit_item' => __( 'Edit Type','savoye' ), 

    'update_item' => __( 'Update Type','savoye' ),

    'add_new_item' => __( 'Add New Type','savoye' ),

    'new_item_name' => __( 'New Type Name','savoye' ),

    'menu_name' => __( 'Type','savoye' ),

  );     



// Now register the taxonomy



  register_taxonomy('type2',array('Service'), array(

    'hierarchical' => true,

    'labels' => $labels,

    'show_ui' => true,

    'show_admin_column' => true,

    'query_var' => true,

    'rewrite' => array( 'slug' => 'type2' ),

  ));



}

?>